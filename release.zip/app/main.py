print("Seohyun Project RUN OK")
input("Press Enter to exit...")
