1. bootstrap\setup_env.bat (최초 1회)
2. run.bat 실행
